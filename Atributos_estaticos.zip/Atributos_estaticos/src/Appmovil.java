public class Appmovil {
    private String nombre;
    private String proveedor;
    private int versionActual; // atributo de instancia, es propio de cada instancia de clase
    public static int ultimaVersion = 0; //variable de clase- Es igual a todas las instancias
    //final  int ultimaVersion = 0;
    //para convertirlo en constante (es decir que no cambie, tengo que usar la palbra final


    //sobreescritura del metodo constructor.
    //usando Polimorfismo
    public Appmovil(String nombre, String proveedor){
        this.nombre=nombre;
        this.proveedor=proveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public String getProveedor() {
        return proveedor;
    }

    public int getVersionActual() {
        return versionActual;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setVersionActual(int versionActual) {
        this.versionActual = versionActual;
    }

    public int actualizar(){
        return versionActual++;
    }

    public String consultarActualizacion(){
        if (versionActual<ultimaVersion){
            return "Aplicación atrasada. Actualización disponible";
        }else{
            return "Aplicación en su última version";
        }
    }
}
